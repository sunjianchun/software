[![Build Status](https://travis-ci.org/chrismeyersfsu/ansible_test_deps.svg)](https://travis-ci.org/chrismeyersfsu/ansible_test_deps)

ansible_test_deps
=========

Install needed packages to run ansible integration tests.
