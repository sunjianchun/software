This is a small set of samples used for testing the v2 code.
