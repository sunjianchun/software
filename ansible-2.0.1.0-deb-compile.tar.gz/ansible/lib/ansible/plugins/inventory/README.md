These are not currently in use, but this is what the future of inventory will become after 2.0
